export const companyInfo = `
Giới thiệu:
Tôi là chatbot H&K shop
Size:
Hiện có 4 size bạn có thể chọn trong cửa hàng: S, M, L, XL.
Liên hệ:
Bạn có thể liên hệ trưc tiếp với chúng tôi để tư vấn thông qua FB https://www.facebook.com/vinhhieu.0807 hoặc qua sđt 0869600976
Thanh toán:
Hiện tại shop có 2 phương thức thanh toán: Thanh toán khi nhận hàng và thanh toán bằng paypal.
Loại:
Hiện tại shop có 11 loại hình áo anime bao gồm:AOT,Chainsaw Man,Conan,Demon Slayer,Dragon Ball,Jujutsu Kaisen,My Hero Academia,Naruto,One Piece,Pokemon,Tokyo Ghoul
Áo:
Tổng cộng có 65 áo
- AOT:
    - Áo Thun Anime Attack On Titan HAVANA Form Rộng Vải Cotton Thoáng Mát Nam Nữ Unisex Mã 018 - Giá: 350.000 vnđ - Giảm giá: 10%
    - Áo Thun Armored Titan HAVANA Form Rộng In Hình Anime Attack On Titan Vải Cotton Nam Nữ Unisex Mã 012 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Anime Attack On Titan HAVANA In Hình Eren , Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 002 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Phông Anime Attack On Titan HAVANA Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 029 - Giá: 350.000 vnđ - Giảm giá: 10%
    - Áo Thun Mikasa HAVANA Form Rộng In Hình Anime Attack On Titan Vải Cotton Nam Nữ Unisex Mã 041 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Eren HAVANA Form Rộng In Hình Anime Attack On Titan Vải Cotton Nam Nữ Unisex Mã 001 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Mikasa HAVANA Form Rộng In Hình Anime Attack On Titan Vải Cotton Nam Nữ Unisex Mã 033 - Giá: 350.000 vnđ - Giảm giá: 0%
- Chainsaw Man:
    - Áo Phông Anime Chainsaw Man HAVANA , Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 002 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Anime Chainsaw Man Power HAVANA Form Rộng Vải Cotton Thoáng Mát Nam Nữ Unisex Mã 009 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Thun Anime Chainsaw Man HAVANA Form Rộng In Hình Denji Pochita Vải Cotton Nam Nữ Unisex Mã 007 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Anime Chainsaw Man HAVANA Form Rộng In Hình Denji Pochita Vải Cotton Nam Nữ Unisex Mã 004 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Anime Chainsaw Man HAVANA Form Rộng In Hình Denji Pochita Vải Cotton Nam Nữ Unisex Mã 003 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Phông Anime Chainsaw Man HAVANA , Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 005 - Giá: 350.000 vnđ - Giảm giá: 10%
    - Áo Thun Anime Chainsaw Man HAVANA Form Rộng In Hình Denji Pochita Vải Cotton Nam Nữ Unisex Mã 008 - Giá: 350.000 vnđ - Giảm giá: 5%
- Conan:
    - Áo Hoodie Kaito Kid Anime Detective Conan 646 - Giá: 500.000 vnđ - Giảm giá: 5%
- Demon Slayer:
    - Áo Thun Zenitsu HAVANA Form Rộng In Hình Anime Demon Slayer Vải Cotton Nam Nữ Unisex Mã 012 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Thun Anime Demon Slayer HAVANA Form Rộng Vải Cotton Thoáng Mát Nam Nữ Unisex Mã 050 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Phông Demon Slayer HAVANA Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 057 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Zenitsu Anime Demon Slayer HAVANA Form Rộng , Vải Cotton Thoáng Mát Kiểu Dáng Cá Tính Mã 045 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Thun Zenitsu HAVANA Form Rộng In Hình Anime Demon Slayer Vải Cotton Nam Nữ Unisex Mã 020 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Phông Demon Slayer HAVANA Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 049 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Nezuko HAVANA Form Rộng In Hình Anime Demon Slayer Vải Cotton Nam Nữ Unisex Mã 002 - Giá: 350.000 vnđ - Giảm giá: 0%
- Dragon Ball:
    - Áo Thun Songoku HAVANA Form Rộng In Hình Anime Dragon Ball Vải Cotton Nam Nữ Unisex Mã 016 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Dragon Ball HAVANA In Hình Anime Songoku Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 023 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Anime Dragon Ball HAVANA Form Rộng In Hình Anime Goku Vải Cotton Nam Nữ Unisex Mã 060 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Songoku HAVANA Form Rộng In Hình Anime Dragon Ball Vải Cotton Nam Nữ Unisex Mã 173 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Goku HAVANA Form Rộng In Hình Anime Dragon Ball Vải Cotton Nam Nữ Unisex Mã 35 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Songoku HAVANA Form Rộng In Hình Anime Dragon Ball Vải Cotton Nam Nữ Unisex Mã 31 - Giá: 350.000 vnđ - Giảm giá: 0%
- Jujutsu Kaisen:
    - Áo thun Anime Jujutsu Kaisen - Suguru Geto cực chất giá rẻ siêu HOT - Giá: 350.000 vnđ - Giảm giá: 10%
    - Áo thun Anime Jujutsu Kaisen - Gojo Satoru Chibi cực chất giá rẻ siêu HOT - Giá: 350.000 vnđ - Giảm giá: 5%
- My Hero Academia:
    - Áo Thun In Hình Anime My Hero Academia HAVANA Hai Màu Đen Trắng Vải Cotton Cao Cấp Mã 001 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun In Hình Anime My Hero Academia HAVANA Form Rộng , Chất Liệu Cotton Cao Cấp Mã 032 - Giá: 350.000 vnđ - Giảm giá: 15%
    - Áo Anime My Hero Academia HAVANA Hình In Đẹp Sắc Nét Hai Màu Đen Trắng , Áo Unisex Chất Liệu Cotton Thoáng Mát Mã 006 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun In Hình Anime My Hero Academia HAVANA Hai Màu Đen Trắng Vải Cotton Cao Cấp Mã 007 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Thun Anime My Hero Academia HAVANA , Chất Liệu Cotton Mềm Mát Kiểu Dáng Cá Tính Mã 062 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Thun Anime My Hero Academia HAVANA Hai Màu Đen Trắng , Chất Liệu Cotton Mềm Mát Kiểu Dáng Cá Tính Mã 044 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Thun Anime My Hero Academia HAVANA Hai Màu Đen Trắng , Chất Liệu Cotton Mềm Mát Kiểu Dáng Cá Tính Mã 004 - Giá: 350.000 vnđ - Giảm giá: 0%
- Naruto:
    - Áo Thun In Naruto Local Brand HAVANA Form Rộng In Hình Anime Naruto Vải Cotton Nam Nữ Unisex Mã 055 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Thun Anime Naruto Local Brand HAVANA Form Rộng In Hình Naruto Vải Cotton Nam Nữ Unisex Mã 22 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Anime Local Brand HAVANA Form Rộng In Hình Naruto Vải Cotton Nam Nữ Unisex Mã 061 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun In Naruto Local Brand HAVANA Form Rộng In Hình Anime Naruto Vải Cotton Nam Nữ Unisex Mã 100 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Naruto Local Brand HAVANA Áo Thun Form Rộng In Hình Anime Vải Cotton Nam Nữ Unisex Mã 21 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Anime Naruto HAVANA Form Rộng In Hình Naruto Vải Cotton Nam Nữ Unisex Mã 106 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Anime Naruto Local Brand HAVANA Form Rộng In Hình Naruto Vải Cotton Nam Nữ Unisex Mã 03 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Thun Anime Naruto Local Brand HAVANA Form Rộng In Hình Naruto Vải Cotton Nam Nữ Unisex Mã 141 - Giá: 350.000 vnđ - Giảm giá: 0%
- One Piece:
    - Áo Phông One Piece Luffy HAVANA Áo Thun Form Rộng In Hình Anime Vải Cotton Nam Nữ Unisex Mã 071 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo One Piece HAVANA In Hình Anime Luffy Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 066 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo One Piece HAVANA In Hình Anime Luffy Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 058 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Phông One Piece HAVANA Áo Thun Form Rộng In Hình Anime Luffy Mũ Rơm Vải Cotton Nam Nữ Unisex Mã 003 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo thun in hình Luffy gear 5 vs kaido -luffy (đen) 100% COTTON LF006 - Giá: 200.000 vnđ - Giảm giá: 0%
    - Áo Thun Luffy Mũ Rơm HAVANA Form Rộng In Hình Anime One Piece Vải Cotton Nam Nữ Unisex Mã 03 - Giá: 314.000 vnđ - Giảm giá: 0%

- Pokemon:
    - Áo Anime Pokemon HAVANA Hình In Đẹp Sắc Nét Hai Màu Đen Trắng , Áo Unisex Chất Liệu Cotton Thoáng Mát Mã 035 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun In Hình Anime My Pokemon HAVANA Form Rộng Hai Màu Đen Trắng , Chất Liệu Cotton Cao Cấp Mã 016 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Anime Pokemon HAVANA Hình In Đẹp Sắc Nét Hai Màu Đen Trắng , Áo Unisex Chất Liệu Cotton Thoáng Mát Mã 006 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun In Hình Anime My Pokemon HAVANA Form Rộng Hai Màu Đen Trắng , Chất Liệu Cotton Cao Cấp Mã 008 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Anime Pokemon HAVANA Hình In Đẹp Sắc Nét Hai Màu Đen Trắng , Áo Unisex Chất Liệu Cotton Thoáng Mát Mã 009 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Anime Pokemon HAVANA Hình In Đẹp Sắc Nét Hai Màu Đen Trắng , Áo Unisex Chất Liệu Cotton Thoáng Mát Mã 013 - Giá: 350.000 vnđ - Giảm giá: 0%
- Tokyo Ghoul:
    - Áo Thun Kaneki Ken HAVANA Form Rộng In Hình Anime Tokyo Ghoul Vải Cotton Nam Nữ Unisex Mã 017 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Phông Anime Tokyo Ghoul Kaneki Ken HAVANA , Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 016 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Anime Tokyo Ghoul HAVANA In Hình Touka , Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 019 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Thun Anime Tokyo Ghoul HAVANA Form Rộng Vải Cotton Thoáng Mát Nam Nữ Unisex Mã 011 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Phông Anime Tokyo Ghoul Kaneki Ken HAVANA , Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 012 - Giá: 350.000 vnđ - Giảm giá: 10%
    - Áo Thun Anime Tokyo Ghoul HAVANA Form Rộng Vải Cotton Thoáng Mát Nam Nữ Unisex Mã 008 - Giá: 350.000 vnđ - Giảm giá: 5%
    - Áo Anime Tokyo Ghoul HAVANA In Hình Touka , Áo Thun Form Rộng Vải Cotton Nam Nữ Unisex Mã 014 - Giá: 350.000 vnđ - Giảm giá: 0%
    - Áo Thun Kaneki Ken HAVANA Form Rộng In Hình Anime Tokyo Ghoul Vải Cotton Nam Nữ Unisex Mã 015 - Giá: 350.000 vnđ - Giảm giá: 5%
`;
